Data file name: cowMilkSippel2009.csv
Dataset title: Milk production responses of primiparous and multiparous dairy cows to dose of conjugated linoleic acid consumed in rumen inert form
Authors: Melanie Ann Sippel, R. S. Spratt, and John P. Cant
Date of README file creation: September 16, 2021
Date of last modified: September 28, 2021
Companion file name: cowMilkSippel2009.csv
Depositors: Jaber Husiny and Michelle Edwards

	sq = square
	per = block 
	trt = treatment
	milk = milk yield (kg d-1)
	fat = fat yield (g d-1)
	prot = protein yield (g d-1)
	lac = lactose yield (g d-1)
	dmi = dry matter intake (kg d-1)
	bw = body weight (kg) 
	


